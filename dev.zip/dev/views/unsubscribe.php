
    <!-- Header -->
    <div class="header bg-danger pt-4 pb-6">
    	
      <div class="container-fluid">
      	<div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Unsubscribe</h6>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col">
          <div class="card">
            <div class="card-header bg-transparent" style="border-bottom: 0px">
              <div class="row align-items-center">
                <div class="col">
                  <h6 class="text-light text-uppercase ls-1 mb-1">Overview</h6>
                  <h5 class="h3 mb-0">Unsubscribe list</h5>
                </div>
                <div class="col">
                  <ul class="nav nav-pills justify-content-end">
                    <li id="tb" class="nav-item" style="display: none;">
                      <a href="#" onclick="showtb()" class="nav-link py-2 px-3 active bg-danger">
                        <span>Table</span>
                      </a>
                    </li>
                    <li id="ta" class="nav-item">
                      <a href="#" onclick="showta()" class="nav-link py-2 px-3 active bg-danger">
                        <span>Text Area</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <!-- Light table -->
            <div id="dtb" class="table-responsive mb-4 px-4">
              <table class="table table-bordered" id="myTable">
                <thead class="thead-light">
                  <tr>
                    <th style="display: none;">No</th>
                    <th>Tanggal</th>
                    <th>No Whatsapp</th>
                    <th>Device</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    $no=1;
                    foreach($data_unsub as $row) {
                      $id      = $row['id'];
                      $wa      = $row['wa'];
                      $tanggal = $row['tanggal'];
                      $tgl     = date_create($tanggal);
                      $device  = $row['device'];
                  ?>
                  <tr>
                    <td class="p-2" style="display: none;"><?= $no ?></td>
                    <td class="p-2"><?= date_format($tgl,"d F Y H:i:s") ?></td>
                    <td class="p-2"><a href="http://wa.me/<?= $wa ?>" target="_blank"><?= $wa ?></a></td>
                    <td class="p-2"><?= $device ?></td>
                  </tr>
                  <?php $no++; } ?>
                </tbody>
              </table>
            </div>

            <div id="dta" class="p-4" style="display: none">
              <textarea id="mytextarea" class="col-12 form-control" rows="20">
                <?php
                  $tglx = "";
                  foreach($data_unsub as $row) {
                    $wa      = $row['wa'];
                    $tanggal = $row['tanggal'];
                    $tgl     = date_create($tanggal);
                    $tgl2    = date_format($tgl,"d F Y");
                    if ($tgl2!=$tglx){
                      echo PHP_EOL."===== ".$tgl2." =====".PHP_EOL;
                      $tglx = $tgl2;
                    }
                    echo $wa.",".PHP_EOL;
                  } 
                ?>
              </textarea>
              <div class="row mt-3">
                <div class="col text-right">
                  <button type="button" onclick="saveTxt('mytextarea')" class="btn btn-md btn-danger rounded">Download as TXT</button>
                  <button type="button" onclick="copyTxt('mytextarea')" class="btn btn-md btn-danger rounded">Copy</a>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>

    <script type="text/javascript">
      function showta(){
        document.getElementById("tb").style.display="block";
        document.getElementById("ta").style.display="none";
        document.getElementById("dtb").style.display="none";
        document.getElementById("dta").style.display="block";
      }
      function showtb(){
        document.getElementById("ta").style.display="block";
        document.getElementById("tb").style.display="none";
        document.getElementById("dta").style.display="none";
        document.getElementById("dtb").style.display="block";
      }
      function saveTxt(id){
        var d = new Date();
        var month = '' + (d.getMonth() + 1);
        var day   = '' + d.getDate();
        var year  = d.getFullYear();
        if (month.length < 2){month = '0' + month;}
        if (day.length < 2) {day = '0' + day;}
        var now = [year, month, day].join('-');
        
        var textcontent = document.getElementById(id).value;
        var downloadableLink = document.createElement('a');
        downloadableLink.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(textcontent));
        downloadableLink.download = now+".txt";
        document.body.appendChild(downloadableLink);
        downloadableLink.click();
        document.body.removeChild(downloadableLink);
      }
      function copyTxt(id) {
        let textarea = document.getElementById(id);
        textarea.select();
        document.execCommand("copy");
        swal('Berhasil', 'Teks berhasil dicopy', 'success');
      }
    </script>