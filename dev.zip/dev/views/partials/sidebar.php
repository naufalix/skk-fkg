<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header  align-items-center">
        <a class="navbar-brand" href="javascript:void(0)">
          <img src="assets/img/brand/red.png" class="navbar-brand-img" alt="logo" style="max-height: 50px;">
        </a>
      </div>
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" href="dashboard">
                <i class="ni ni-tv-2 text-danger"></i>
                <span class="nav-link-text ">Homepage</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="unsubscribe">
                <i class="fa fa-bell-slash text-danger"></i>
                <span class="nav-link-text">Unsubscribe</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="user">
                <i class="ni ni-single-02 text-danger"></i>
                <span class="nav-link-text">User Management</span>
              </a>
            </li>
            <!-- <li class="nav-item">
              <a data-toggle="collapse" href="#basicExamples" class="nav-link" href="#" aria-controls="basicExamples" role="button" aria-expanded="false">
                <i class="ni ni-cloud-upload-96 text-green"></i>
                <span class="nav-link-text">Submit TL / TS</span>
              </a>
              <div class="collapse " id="basicExamples">
                <ul class="nav ms-4">
                  <li class="nav-item">
                    <a class="nav-link" href="tl">
                      <i class="ni ni-cloud-upload-96 text-green"></i>
                      <span class="nav-link-text">Submit TL</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="ts">
                      <i class="ni ni-cloud-upload-96 text-green"></i>
                      <span class="nav-link-text">Submit TS (zip)</span>
                    </a>
                  </li>
                </ul>
              </div>
            </li> -->
          </ul>
          <!-- Divider -->
          
        </div>
      </div>
    </div>
  </nav>