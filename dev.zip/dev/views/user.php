
    <!-- Header -->
    <div class="header bg-danger pt-4 pb-6">
    	
      <div class="container-fluid">
      	<div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">User Management</h6>
            </div>
            <div class="col-lg-6 col-5 text-right">
              <a href="#" class="btn btn-default btn-sm" data-toggle="modal" data-target="#tambah">Add New User</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col">
          <div class="card">
            <div class="card-header bg-transparent" style="border-bottom: 0px">
              <div class="row align-items-center">
                <div class="col">
                  <h6 class="text-light text-uppercase ls-1 mb-1">Overview</h6>
                  <h5 class="h3 mb-0">Daftar user</h5>
                </div>
                <div class="col">
                  <ul class="nav nav-pills justify-content-end">
                    <li class="nav-item mr-2 mr-md-0" data-toggle="chart" data-target="#chart-sales-dark" data-update='{"data":{"datasets":[{"data":[0, 20, 10, 30, 15, 40, 20, 60, 60]}]}}' data-prefix="$" data-suffix="k">
                      <a href="#" class="nav-link py-2 px-3 active bg-danger" data-toggle="tab">
                        <span class="d-none d-md-block">Month</span>
                        <span class="d-md-none">M</span>
                      </a>
                    </li>
                    <li class="nav-item" data-toggle="chart" data-target="#chart-sales-dark" data-update='{"data":{"datasets":[{"data":[0, 20, 5, 25, 10, 30, 15, 40, 40]}]}}' data-prefix="$" data-suffix="k">
                      <a href="#" class="nav-link py-2 px-3 text-danger" data-toggle="tab">
                        <span class="d-none d-md-block">Week</span>
                        <span class="d-md-none">W</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <!-- Light table -->
            <div class="table-responsive mb-4 px-4">
              <table class="table table-bordered" id="myTable">
                <thead class="thead-light">
                  <tr>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    $no=1;
                    foreach($data_user as $row) {
                      $id         = $row['id'];
                      $nama       = $row['nama'];
                      $username   = $row['username'];
                      $role       = $row['role'];
                      $foto       = $row['foto'];
                      if (empty($foto)) {$foto="default.png";}
                  ?>
                  <tr>
                    <td>
                      <div class="media align-items-center">
                        <img class="rounded-circle mr-3" width="30" height="30" src="assets/img/users/<?= $foto ?>" style="object-fit: cover">
                        <span class="name mb-0 text-sm"><?= $nama ?></span>
                      </div>
                    </td>
                    <td><?= $username ?></td>
                    <td>
                      <span class="badge bg-gradient-danger text-white" style="font-size: 12px;"><?= $role ?></span>
                    </td>
                    <td>
                      <button type="button" class="btn btn-sm btn-dark" title="Edit" data-toggle="modal" data-target="#edit" onclick="edit(<?= $id ?>)"><i class="fa fa-pen"></i></button>
                      <p id="<?= $id ?>" class="d-none"><?php echo $nama.'|'.$username.'|'.$role ?></p>
                      <button type="button" class="btn btn-sm btn-dark" title="Edit foto" data-toggle="modal" data-target="#foto" onclick="foto(<?= $id ?>)"><i class="fa fa-camera"></i></button>
                      <button type="button" class="btn btn-sm btn-danger" title="Hapus" data-toggle="modal" data-target="#hapus" onclick="hapus(<?= $id ?>)"><i class="fa fa-trash"></i></button>
                    </td>
                  </tr>
                  <?php $no++; } ?>
                </tbody>
              </table>
            </div>

          </div>
        </div>
      </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah User</h5>
          </div>
          <form method="post">
            <div class="modal-body">
              <div class="form-group">
                <div class="row m-0">
                  <div class="col-6 p-0 pr-2">
                    <label for="nama" class="form-control-label">Nama</label>
                    <input type="text" class="form-control" placeholder="Nama" name="nama" required>
                  </div>
                  <div class="col-6 p-0 pr-2">
                    <label for="username" class="form-control-label">Username</label>
                    <input type="text" class="form-control" placeholder="Username" name="username" required>
                  </div>
                </div>
              </div>
              <div class="form-group m-0">
                <div class="row m-0">
                  <div class="col-6 p-0 pr-2">
                    <label for="password" class="form-control-label">Password</label>
                    <input type="password" class="form-control" name="password" required>
                    <label class="d-none text-danger form-control-label">*kosongkan jika tidak ingin mengubah password</label>
                  </div>
                  <div class="col-6 p-0 pr-2">
                    <label for="role" class="form-control-label">Role</label>
                    <select class="form-control" name="role">
                      <option class="el" value="admin">Admin</option>
                      <option class="el" value="user">User</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn bg-gradient-secondary" data-dismiss="modal">Cancel</button>
              <button type="submit" class="btn bg-gradient-danger text-white" name="submit-tambah">Submit</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="et">Edit User</h5>
          </div>
          <form method="post">
            <div class="modal-body">
              <input type="hidden" id="ei" name="id" required>
              <div class="form-group">
                <div class="row m-0">
                  <div class="col-6 p-0 pr-2">
                    <label for="nama" class="form-control-label">Nama</label>
                    <input type="text" class="form-control" id="en" placeholder="Nama" name="nama" required>
                  </div>
                  <div class="col-6 p-0 pr-2">
                    <label for="username" class="form-control-label">Username</label>
                    <input type="text" class="form-control" id="eu" placeholder="Username" name="username" required>
                  </div>
                </div>
              </div>
              <div class="form-group m-0">
                <div class="row m-0">
                  <div class="col-6 p-0 pr-2">
                    <label for="password" class="form-control-label">Password</label>
                    <input type="password" class="form-control" name="password">
                    <label class="text-danger form-control-label">*kosongkan jika tidak ingin mengubah password</label>
                  </div>
                  <div class="col-6 p-0 pr-2">
                    <label for="role" class="form-control-label">Role</label>
                    <select class="form-control" name="role">
                      <option class="er" value="admin">Admin</option>
                      <option class="er" value="user">User</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn bg-gradient-secondary" data-dismiss="modal">Cancel</button>
              <button type="submit" class="btn bg-gradient-danger text-white" name="submit-edit">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="modal fade" id="foto" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="ft">Edit User</h5>
          </div>
          <form method="post" enctype="multipart/form-data">
            <div class="modal-body">
              <input type="hidden" id="fi" name="id" required>
              <div class="form-group m-0">
                <label for="foto" class="form-control-label">Upload foto :</label>
                <input type="file" class="form-control" name="foto" required style="height: auto">
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn bg-gradient-secondary" data-dismiss="modal">Cancel</button>
              <button type="submit" class="btn bg-gradient-danger text-white" name="submit-foto">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="modal fade" id="hapus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Hapus User</h5>
          </div>
          <form method="post" enctype="multipart/form-data">
            <div class="modal-body">
              <div class="form-group m-0">
                <label id="ht" class="form-control-label">Apakah anda yakin ingin menghapus user ini?</label>
                <input type="hidden" class="d-none" class="form-control" id="hi" name="id" value="" required>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn bg-gradient-secondary" data-dismiss="modal">Cancel</button>
              <button type="submit" class="btn bg-gradient-danger text-white" name="submit-hapus">Hapus</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <script type="text/javascript">
      function edit(id){
        var data = (document.getElementById(id).textContent).split("|");
        document.getElementById("ei").value = id;
        document.getElementById("en").value = data[0];
        document.getElementById("eu").value = data[1];
        document.getElementById("et").textContent = "Edit "+data[0];
        for (var i = 0; i < document.getElementsByClassName("er").length ; i++) {
          if (document.getElementsByClassName("er")[i].value==data[2]) {
            document.getElementsByClassName("er")[i].selected = "true";
          }
        }
      }
      function foto(id){
        var data = (document.getElementById(id).textContent).split("|");
        document.getElementById("fi").value = id;
        document.getElementById("ft").textContent = 'Edit foto '+data[0];
      }
      function hapus(id){
        var data = (document.getElementById(id).textContent).split("|");
        document.getElementById("hi").value = id;
        document.getElementById("ht").textContent = 'Apakah anda yakin ingin menghapus "'+data[0]+'"?';
      }
    </script>