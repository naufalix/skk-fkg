<?php 
  require("models/unsubscribe.php");
  $unsub = new unsubscribe();

  if (isset($_GET["phone"])) {
    $phone = $_GET["phone"];
  }
  else {
    $phone = "";
  }

  if (isset($_POST["btn-unsub"])) {
    if (!empty($_POST["phone"])) {
      $p = $_POST["phone"];
      $t = date("Y-m-d H:i:s");
      $d = $_SERVER['HTTP_USER_AGENT'];
      $unsub->tambah($p,$t,$d);
      $success = "Unsubscribe berhasil";
    }else {$error = "Gagal!";}
  }
?>