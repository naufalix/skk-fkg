<?php
  require("models/unsubscribe.php");
  $unsub = new unsubscribe();
  
  /* Tambah */ 
  // if (isset($_POST["btn-unsub"])) {
  //   if (!empty($_POST["phone"])) {
  //     $p = $_POST["phone"];
  //     $t = date("Y-m-d H:i:s");
  //     $d = $_SERVER['HTTP_USER_AGENT'];
  //     $unsub->tambah($p,$t,$d);
  //     $success = "Unsubscribe berhasil";
  //   }else {$error = "Gagal!";}
  // }

  $data_unsub = $unsub->tampil();
?>