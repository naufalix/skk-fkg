<?php
  //require("models/user.php");
  if ($role!="admin") {
    //header("Location:404");
    $page="404";
  }
  $user = new user();
  
  /* Tambah */ 
  if (isset($_POST["submit-tambah"])) {
    if (!empty($_POST["nama"])&&!empty($_POST["username"])&&!empty($_POST["password"])&&!empty($_POST["role"])) {
      $n = $_POST["nama"];
      $u = $_POST["username"];
      $p = MD5($_POST["password"]);
      $r = $_POST["role"];
      if (!($user->cek_username($u))) {
        $user->tambah($n,$u,$p,$r);
        $success = "Akun berhasil ditambahkan";
      } else {$error = "Username telah terpakai";}
    }else {$error = "Semua data wajib diisi!";}
  }

  /* Edit */
  if (isset($_POST["submit-edit"])) {
    if (!empty($_POST["nama"])&&!empty($_POST["username"])&&!empty($_POST["id"])&&!empty($_POST["role"])) {
      $i = $_POST["id"];
      $n = $_POST["nama"];
      $u = $_POST["username"];
      $r = $_POST["role"];
      $ul = $user->tampil_id($i)["username"];
      if ($u==$ul) {
        $user->ubah($i,$n,$u,$r);
        if (!empty($_POST["password"])) {
          $p = MD5($_POST["password"]);
          $user->password($i,$p);
        }
        $success = "Akun berhasil diedit";
      }
      if ($u!=$ul) {
        if (!($user->cek_username($u))) {
          $user->ubah($i,$n,$u,$r);
          if (!empty($_POST["password"])) {
            $p = MD5($_POST["password"]);
            $user->password($i,$p);
          }
          $success = "Akun berhasil di edit";
        } else {$error = "Username ".$u." telah terpakai";}
      }
    } else {$error = "Semua data selain password wajib diisi!";}
  }

  /* Edit Foto*/ 
  if (isset($_POST["submit-foto"])) {
    if (!empty($_POST['id'])&&!empty($_FILES['foto'])) {
      $i       = $_POST["id"];
      $f_tmp   = $_FILES['foto']['tmp_name'];
      $f_name  = $_FILES['foto']['name']; 
      $f_exp   = explode('.',$f_name);
      $f_ext   = end($f_exp);
      $n       = $i.".png";
      $dir     = 'assets/img/users/'.$n;
      if(move_uploaded_file($f_tmp,$dir)){ 
        $user->foto($i,$n);
        $success="Foto berhasil diupload";
      }else{
        $error="Foto gagal diupload";
      }
    }
  }

  /* Hapus User*/ 
  if (isset($_POST["submit-hapus"])) {
    if (!empty($_POST["id"])) {
      $i = $_POST["id"];
      //get foto
      $f = $user->tampil_id($i)["foto"];
      $n = $user->tampil_id($i)["nama"];
      unlink("assets/img/users/$f");
      $user->hapus($i);
      $success = $n." berhasil dihapus";
    }
  } 

  $data_user = $user->tampil();
?>